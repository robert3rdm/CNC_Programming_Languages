// a first program with
// two comment lines
int main() {
    char c;
    int i;
    int math;
		c = 'h';
		math = 1*2+(2/2)-1;
    i = c + 3 * 5;
		if (math == 3){
			return true;
		}else if (math>2){
			return true;
		}else if (math>=2){
			return true
}
 
} // main
