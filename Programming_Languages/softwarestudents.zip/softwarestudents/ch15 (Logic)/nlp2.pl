s --> np, vp. 

np --> det, n. 

vp --> iv. 
vp --> tv, np. 

det --> [the]. 
det --> [a]. 
n --> [giraffe]. 
n --> [apple]. 
iv --> [dreams]. 
tv --> [dreams]. 
tv --> [eats]. 
