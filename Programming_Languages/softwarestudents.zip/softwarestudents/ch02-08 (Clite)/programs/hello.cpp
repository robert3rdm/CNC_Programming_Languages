// a first program with
// two comment lines
int main() {
    char c;
    int i;
    c = 'h';
    i = c + 3;
} // main
